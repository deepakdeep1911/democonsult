import "./App.css";
import Header from "./components/header/Header";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import { createTheme, ThemeProvider } from "@mui/material/styles";

import Home from "./containers/Home/Home";

import Profile from "./containers/Profile/Profile";
import LoginScreen from "./containers/LoginScreen";
import UserRegistration from "./containers/Registration/UserRegistration";

import ConsultChat from "./containers/consultChat/ConsultChat";
import ConsultForm from "./containers/consult/ConsultForm";
import DocConsultList from "./containers/DocConsultList";
import PatientConsultList from "./containers/PatientConsultList";
import ResetPassword from "./containers/resetPassword/ResetPassword";
import ConfirmResetPassword from "./containers/resetPassword/ConfirmResetPassword";
import Thanks from "./containers/successMessage/thanksMessage";

import PatientRoute from "./routing/PatientRoute";
import DoctorRoute from "./routing/DoctorRoute";
import AuthRoute from "./routing/AuthRoute";
import PageNotFound from "./containers/pageNotFound/pageNotFound";
import CommonRoute from "./routing/CommonRoute";
import { Container } from "react-bootstrap";
import ChangePassword from "./components/ChangePassword";

const theme = createTheme({});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <BrowserRouter>
        <Header />
        <main className="py-3">
          <Container>
            <Switch>
              <Route path="/" exact component={Home} />
              <CommonRoute path="/userprofile" exact component={Profile} />
              <AuthRoute path="/userlogin" exact component={LoginScreen} />
              <Route path="/change/password" exact component={ChangePassword} />
              <AuthRoute
                path="/user/registration"
                exact
                component={UserRegistration}
              />
              <DoctorRoute
                path="/doctor/consultList"
                exact
                component={DocConsultList}
              />
              <PatientRoute
                path="/patient/consultList"
                exact
                component={PatientConsultList}
              />
              <PatientRoute path="/consult" exact component={ConsultForm} />
              <CommonRoute
                path="/message/:consult_id"
                exact
                component={ConsultChat}
              />
              <Route exact path="/reset-password" component={ResetPassword} />
              <Route
                exact
                path="/password/reset/confirm"
                component={ConfirmResetPassword}
              />
              <Route exact path="/verified" component={Thanks} />
              <Route component={PageNotFound} />
            </Switch>
          </Container>
        </main>
        {/* <Footer /> */}
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
