import {
  CHAT_LIST_REQUEST,
  CHAT_LIST_SUCCESS,
  CHAT_LIST_FAIL,
  CHAT_LIST_RESET,
  CHAT_ADD,
} from "../../constants/userConstants";
// Chat list reducer

const initialState = { chat: [] };

export const chatListReducer = (state = initialState, action) => {
  switch (action.type) {
    case CHAT_LIST_REQUEST:
      // request
      return { loading: true };

    case CHAT_LIST_SUCCESS:
      // success
      return { loading: false, chat: action.payload };
    case CHAT_ADD:
      return { ...state, chat: [...state.chat, action.payload] };
    // ...state,
    // projectList: [...state.projectList, ...action.payload]
    case CHAT_LIST_FAIL:
      // fail
      return { loading: false, error: action.payload };

    case CHAT_LIST_RESET:
      // reset
      return { chat: [] };

    default:
      return state;
  }
};
