import {
  // Doctor consult list Constants
  DOC_CONSULT_LIST_REQUEST,
  DOC_CONSULT_LIST_FAIL,
  DOC_CONSULT_LIST_RESET,
  DOC_CONSULT_LIST_SUCCESS,

  // Patient consult list Constants
  PAT_CONSULT_LIST_FAIL,
  PAT_CONSULT_LIST_REQUEST,
  PAT_CONSULT_LIST_RESET,
  PAT_CONSULT_LIST_SUCCESS,

  // append changes for both patient and doctor
  LIST_ADD,

  // withdraw consult for patient
  PAT_CONSULT_WITHDRAW_REQUEST,
  PAT_CONSULT_WITHDRAW_SUCCESS,
  PAT_CONSULT_WITHDRAW_FAIL,
} from "../../constants/userConstants";

// Consult List for doctor reducer

export const docConsultListReducer = (state = { consults: [] }, action) => {
  switch (action.type) {
    case DOC_CONSULT_LIST_REQUEST:
      // request
      return { loading: true };

    case DOC_CONSULT_LIST_SUCCESS:
      // success
      return {
        loading: false,
        consults: action.payload.consults,
        page: action.payload.page,
        pages: action.payload.pages,
      };

    case LIST_ADD:
      const consultObj = action.payload;
      const arrIndex = state.consults.findIndex(
        (obj) => obj.consult_id === consultObj.consult_id
      );

      const newConsults = [...state.consults];
      newConsults[arrIndex] = consultObj;

      // append changes for accept and reject for doctor
      return { ...state, consults: newConsults };

    case DOC_CONSULT_LIST_FAIL:
      // fail
      return { loading: false, error: action.payload };

    case DOC_CONSULT_LIST_RESET:
      // reset
      return { consults: [] };

    default:
      return state;
  }
};

// Consult List for patient reducer
export const patConsultListReducer = (state = { consults: [] }, action) => {
  switch (action.type) {
    case PAT_CONSULT_LIST_REQUEST:
      // request
      return { loading: true };

    case PAT_CONSULT_LIST_SUCCESS:
      // success
      return {
        loading: false,
        consults: action.payload.consults,
        page: action.payload.page,
        pages: action.payload.pages,
      };

    case LIST_ADD:
      // append changes for accept and reject for doctor
      // return { ...state, consults: [...state.consults, action.payload] };
      const consultObj = action.payload;
      const arrIndex = state.consults.findIndex(
        (obj) => obj.consult_id === consultObj.consult_id
      );

      const newConsults = [...state.consults];
      newConsults[arrIndex] = consultObj;

      // append changes for accept and reject for doctor
      return { ...state, consults: newConsults };

    case PAT_CONSULT_LIST_FAIL:
      // fail
      return { loading: false, error: action.payload };

    case PAT_CONSULT_LIST_RESET:
      // reset
      return { consults: [] };

    default:
      return state;
  }
};

// Consult Withdraw for patient reducer
export const patConsultWithdrawReducer = (state = { consult: {} }, action) => {
  switch (action.type) {
    case PAT_CONSULT_WITHDRAW_REQUEST:
      // request
      return { ...state, loading: true };

    case PAT_CONSULT_WITHDRAW_SUCCESS:
      // success
      return {
        loading: false,
        consult: action.payload,
      };

    case PAT_CONSULT_WITHDRAW_FAIL:
      // fail
      return { loading: false, error: action.payload };

    default:
      return state;
  }
};
