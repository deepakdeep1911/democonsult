import {
  // Doctor Consult List Constants
  DOC_CONSULT_LIST_REQUEST,
  DOC_CONSULT_LIST_SUCCESS,
  DOC_CONSULT_LIST_FAIL,

  // Patient Consult List Constants
  PAT_CONSULT_LIST_REQUEST,
  PAT_CONSULT_LIST_SUCCESS,
  PAT_CONSULT_LIST_FAIL,

  // ConsultForm Constants
  CONSULT_FORM_REQUEST,
  CONSULT_FORM_SUCCESS,
  CONSULT_FORM_FAIL,

  // append changes for both patient and doctor
  LIST_ADD,

  // patient withdraw constants
  PAT_CONSULT_WITHDRAW_REQUEST,
  PAT_CONSULT_WITHDRAW_SUCCESS,
  PAT_CONSULT_WITHDRAW_FAIL,
} from "../../constants/userConstants";

import axios from "axios";

// List DoctorConsult Action
export const listDocConsults =
  ({ sortBy, sortOrder, page }) =>
  async (dispatch, getState) => {
    try {
      // request
      dispatch({
        type: DOC_CONSULT_LIST_REQUEST,
      });

      // get userInfo from localStorage
      const {
        userLogin: { userInfo },
      } = getState();

      // send token with request
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${userInfo.token}`,
        },
        // params passed with the request
        params: {
          sortBy,
          sortOrder,
          page,
        },
      };
      // set data variable for data coming from backend
      const { data } = await axios.get(`/doctor/consultlist/`, config);

      dispatch({
        // success
        type: DOC_CONSULT_LIST_SUCCESS,
        payload: data,
      });
    } catch (error) {
      // error handling
      dispatch({
        type: DOC_CONSULT_LIST_FAIL,
        payload:
          error.response && error.response.data.detail
            ? error.response.data.detail
            : error.message,
      });
    }
  };

// append changes for both patient and doctor
export const modifyList = (consult) => async (dispatch, getState) => {
  dispatch({
    type: LIST_ADD,
    payload: consult,
  });
};

// Patient Consults List
export const listPatConsults =
  ({ sortBy, sortOrder, page }) =>
  async (dispatch, getState) => {
    try {
      // request
      dispatch({
        type: PAT_CONSULT_LIST_REQUEST,
      });

      // get userInfo from localStorage
      const {
        userLogin: { userInfo },
      } = getState();

      // send token with request
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${userInfo.token}`,
        },
        // params passed with the request
        params: {
          sortBy,
          sortOrder,
          page,
        },
      };
      // set data variable for data coming from backend
      const { data } = await axios.get(`/patient/consultlist/`, config);

      dispatch({
        // success
        type: PAT_CONSULT_LIST_SUCCESS,
        payload: data,
      });
    } catch (error) {
      // error handling
      dispatch({
        type: PAT_CONSULT_LIST_FAIL,
        payload:
          error.response && error.response.data.detail
            ? error.response.data.detail
            : error.message,
      });
    }
  };

// Patient Consults List
export const patConsultWithdraw =
  (consult_id) => async (dispatch, getState) => {
    try {
      // request
      dispatch({
        type: PAT_CONSULT_WITHDRAW_REQUEST,
      });

      // get userInfo from localStorage
      const {
        userLogin: { userInfo },
      } = getState();

      // send token with request
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${userInfo.token}`,
        },
        // params passed with the request
        params: {},
      };
      // set data variable for data coming from backend
      const { data } = await axios.put(
        `/patientwithdraw/${consult_id}/`,
        config
      );

      dispatch({
        // success
        type: PAT_CONSULT_WITHDRAW_SUCCESS,
        payload: data,
      });
    } catch (error) {
      // error handling
      dispatch({
        type: PAT_CONSULT_WITHDRAW_FAIL,
        payload:
          error.response && error.response.data.detail
            ? error.response.data.detail
            : error.message,
      });
    }
  };

export const consultForm = (params) => async (dispatch, getState) => {
  try {
    dispatch({
      type: CONSULT_FORM_REQUEST,
    });

    const {
      userLogin: { userInfo },
    } = getState();

    const config = {
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${userInfo.token}`,
      },
    };

    const { data } = await axios.post(`/consult/form`, params, config);

    dispatch({
      type: CONSULT_FORM_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: CONSULT_FORM_FAIL,
      payload:
        error.response && error.response.data.detail
          ? error.response.data.detail
          : error.message,
    });
  }
};
