import axios from "axios";
import {
  // Login User Components
  USER_LOGIN_REQUEST,
  USER_LOGIN_SUCCESS,
  USER_LOGIN_FAIL,
  USER_LOGOUT,

  // Regiter  User Components
  USER_REGISTER_REQUEST,
  USER_REGISTER_SUCCESS,
  USER_REGISTER_FAIL,
  RESET_MESSAGES,

  // User Details Components
  USER_DETAILS_REQUEST,
  USER_DETAILS_SUCCESS,
  USER_DETAILS_FAIL,
  USER_DETAILS_RESET,

  // UpdateProfile  Components
  USER_UPDATE_PROFILE_REQUEST,
  USER_UPDATE_PROFILE_SUCCESS,
  USER_UPDATE_PROFILE_FAIL,

  // PasswordReset  Components
  PASSWORD_RESET_CONFIRM_FAIL,
  PASSWORD_RESET_REQUEST,
  PASSWORD_RESET_SUCCESS,
  PASSWORD_RESET_FAIL,
  PASSWORD_RESET_CONFIRM_SUCCESS,
} from "../../constants/userConstants";

/**USER ACTIONS */

// User Register Action
export const register = (params) => async (dispatch) => {
  try {
    dispatch({
      type: USER_REGISTER_REQUEST,
    });

    const config = {
      headers: {
        "Content-type": "application/json",
      },
    };

    const { data } = await axios.post("/register", params, config);

    dispatch({
      type: USER_REGISTER_SUCCESS,
      payload: data.detail,
    });
    return true;
    // dispatch({
    //     type: USER_LOGIN_SUCCESS,
    //     payload: data
    // })

    // localStorage.setItem('userInfo', JSON.stringify(data))
  } catch (error) {
    dispatch({
      type: USER_REGISTER_FAIL,
      payload:
        error.response && error.response.data.detail
          ? error.response.data.detail
          : error.message,
    });
  }
};

// Login Action
export const login = (email, password) => async (dispatch) => {
  try {
    dispatch({
      type: USER_LOGIN_REQUEST,
    });

    // send token info with the request
    const config = {
      headers: {
        "Content-type": "application/json",
      },
    };

    // save 'data' variable for data coming from backend
    const { data } = await axios.post(
      "/login/",
      // set username to email and password to password
      { username: email, password: password },
      config
    );

    // if success
    dispatch({
      type: USER_LOGIN_SUCCESS,
      payload: data,
    });

    // localStorage set item
    localStorage.setItem("userInfo", JSON.stringify(data));
  } catch (error) {
    if (error?.response?.data) {
      // error handling
      dispatch({
        type: USER_LOGIN_FAIL,
        // payload: error?.response?.data || (error.response && error.response.data.detail ? error.response.data.detail : error.message),
        payload:
          error.response && error.response.data.detail
            ? error.response.data.detail
            : error.response.data,
      });
    }
  }
};

// Logout Action
export const logout = () => (dispatch) => {
  // remove items from local storage when the user logs out
  localStorage.removeItem("userInfo");
  dispatch({ type: USER_LOGOUT });
  dispatch({ type: USER_DETAILS_RESET });
};

/***
 * Get UserDetails
 */
export const getUserDetails = (id) => async (dispatch, getState) => {
  try {
    dispatch({
      type: USER_DETAILS_REQUEST,
    });

    const {
      userLogin: { userInfo },
    } = getState();

    const config = {
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${userInfo.token}`,
      },
    };

    const { data } = await axios.get(`/user/${id}/`, config);

    dispatch({
      type: USER_DETAILS_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: USER_DETAILS_FAIL,
      payload:
        error.response && error.response.data.detail
          ? error.response.data.detail
          : error.message,
    });
  }
};

/**
 * Update user Profile
 */

export const updateUserProfile = (user) => async (dispatch, getState) => {
  try {
    dispatch({
      type: USER_UPDATE_PROFILE_REQUEST,
    });

    const {
      userLogin: { userInfo },
    } = getState();

    const config = {
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${userInfo.token}`,
      },
    };
    console.log("...user", user);
    const { data } = await axios.put(`/profile/update`, user, config);

    dispatch({
      type: USER_UPDATE_PROFILE_SUCCESS,
      payload: data,
    });

    localStorage.setItem("userInfo", JSON.stringify(data));
    return true;
  } catch (error) {
    dispatch({
      type: USER_UPDATE_PROFILE_FAIL,
      payload:
        error.response && error.response.data.detail
          ? error.response.data.detail
          : error.message,
    });
  }
};

// Reset Password

export const reset_password = (email) => async (dispatch) => {
  try {
    dispatch({
      type: PASSWORD_RESET_REQUEST,
    });

    const { data } = await axios.post(`/resetpassword`, { email });
    dispatch({
      type: PASSWORD_RESET_SUCCESS,
      payload: data.message,
    });
  } catch (error) {
    dispatch({
      type: PASSWORD_RESET_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

// Reset Confirm Password
export const reset_password_confirm =
  (uid, token, new_password) => async (dispatch) => {
    try {
      const { data } = await axios.post(`/verifyresetpassword`, {
        uid,
        token,
        new_password,
      });
      dispatch({
        type: PASSWORD_RESET_CONFIRM_SUCCESS,
        payload: data,
      });

      return data;
    } catch (err) {
      dispatch({
        type: PASSWORD_RESET_CONFIRM_FAIL,
        payload: err?.response?.data || "Something went wrong",
      });
    }
  };

export const activateAccount = (uid, token) => async (dispatch) => {
  try {
    const { data } = await axios.post(`/activate`, { uid, token });

    return data;
  } catch (err) {}
};

export const resendAccount = (email) => async (dispatch) => {
  try {
    const { data } = await axios.post(`/resendmail`, { email });

    return data;
  } catch (err) {}
};

export const resetMessages = () => async (dispatch) => {
  console.log("resetmessages", resetMessages);
  dispatch({
    type: RESET_MESSAGES,
  });
};
