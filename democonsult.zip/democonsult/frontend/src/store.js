import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import {
  userLoginReducer,
  userUpdateProfileReducer,
  userDetailsReducer,
  userRegisterReducer,
  resetPasswordReducer,
} from "./redux/reducers/AuthReducer";

import {
  patConsultListReducer,
  docConsultListReducer,
  patConsultWithdrawReducer,
} from "./redux/reducers/ConsultReducer";

import { AgeReducer } from "./redux/reducers/AgeReducer";
import { languageReducer } from "./redux/reducers/LanguageReducer";
import { chatListReducer } from "./redux/reducers/ChatReducer";

// Initializing reducers
const reducer = combineReducers({
  // user reducers
  userLogin: userLoginReducer,
  docConsultList: docConsultListReducer,
  patConsultList: patConsultListReducer,
  userUpdateProfileReducer,
  userDetailsReducer,
  AgeReducer,
  languageReducer,
  userRegisterReducer,
  chatListReducer,
  resetPasswordReducer,
  patConsultWithdrawReducer,
});

// get userInfo from localStorage
const userInfoFromStorage = localStorage.getItem("userInfo")
  ? JSON.parse(localStorage.getItem("userInfo"))
  : null;

// initialState
const initialState = {
  userLogin: { userInfo: userInfoFromStorage },
};
// middleware used thunk
const middleware = [thunk];

// store variable initialized
const store = createStore(
  reducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

export default store;
