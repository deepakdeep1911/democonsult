/**
 * This is Footer Page
 */

import React from 'react';

function Footer() {
  return (
  <div className='p-3'>
    <footer data-stellar-background-ratio="5">
          <div className="container">
               <div className="row">

                    <div className="col-md-4 col-sm-4">
                         <div className="footer-thumb"> 
                              <h4 className="wow fadeInUp" data-wow-delay="0.4s">Contact Info</h4>
                              <p>Fusce at libero iaculis, venenatis augue quis, pharetra lorem. Curabitur ut dolor eu elit consequat ultricies.</p>

                              <div className="contact-info">
                                   <p><i className="fa fa-phone"></i> 62802877****</p>
                                   <p><i className="fa fa-envelope-o"></i> <a href="#dee">info@company.com</a></p>
                              </div>
                         </div>
                    </div>

                    <div className="col-md-4 col-sm-4"> 
                         <div className="footer-thumb"> 
                              <h4 className="wow fadeInUp" data-wow-delay="0.4s">Latest News</h4>
                              <div className="latest-stories">
                                   <div className="stories-image">
                                        <a href="#dee"><img src="/static/images/news-image.jpg" className="img-responsive" alt=""/></a>
                                   </div>
                                   <div className="stories-info">
                                        <a href="#dee"><h5>Amazing Technology</h5></a>
                                        <span>March 08, 2018</span>
                                   </div>
                              </div>

                              <div className="latest-stories">
                                   <div className="stories-image">
                                        <a href="#dee"><img src="/static/images/news-image.jpg" className="img-responsive" alt=""/></a>
                                   </div>
                                   <div className="stories-info">
                                        <a href="#dee"><h5>New Healing Process</h5></a>
                                        <span>February 20, 2018</span>
                                   </div>
                              </div>
                         </div>
                    </div>

                    <div className="col-md-4 col-sm-4"> 
                         <div className="footer-thumb">
                              <div className="opening-hours">
                                   <h4 className="wow fadeInUp" data-wow-delay="0.4s">Opening Hours</h4>
                                   <p>Monday - Friday <span>06:00 AM - 10:00 PM</span></p>
                                   <p>Saturday <span>09:00 AM - 08:00 PM</span></p>
                                   <p>Sunday <span>Closed</span></p>
                              </div> 

                              <ul className="social-icon">
                                   <li><a href="#dee" className="fa fa-facebook-square" attr="facebook icon"> </a></li>
                                   <li><a href="#dee" className="fa fa-twitter"> </a></li>
                                   <li><a href="#dee" className="fa fa-instagram"> </a></li>
                              </ul>
                         </div>
                    </div>

                    <div className="col-md-12 col-sm-12 border-top">
                         <div className="col-md-4 col-sm-6">
                              <div className="copyright-text"> 
                                   <p>Copyright &copy; 2022 Your Company 
                                   
                                   | Design: Doc Consult</p>
                              </div>
                         </div>
                         <div className="col-md-6 col-sm-6">
                              <div className="footer-link"> 
                                   <a href="#dee">Laboratory Tests</a>
                                   <a href="#dee">Departments</a>
                                   <a href="#dee">Insurance Policy</a>
                                   <a href="#dee">Careers</a>
                              </div>
                         </div>
                         <div className="col-md-2 col-sm-2 text-align-center">
                              <div className="angle-up-btn"> 
                                  <a href="#top" className="smoothScroll wow fadeInUp" data-wow-delay="1.2s"><i className="fa fa-angle-up"></i></a>
                              </div>
                         </div>   
                    </div>
                    
               </div>
          </div>
     </footer>

  </div>
  )
}

export default Footer;

