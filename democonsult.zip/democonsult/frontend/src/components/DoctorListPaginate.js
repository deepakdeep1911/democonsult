/**
 * Doctor List Pagination
 */

import React from "react";
import { Stack, Pagination } from "@mui/material";
import { useHistory } from "react-router-dom";

function DoctorListPaginate({ pages, page }) {
  const history = useHistory();

  return (
    pages > 1 && (
      <Stack spacing={10} margin="40px 0px">
        <Pagination
          count={pages}
          page={Number(page)}
          onChange={(e, page) =>
            history.push(`/doctor/consultList?page=${page}`)
          }
          shape="rounded"
          variant="outlined"
          size="large"
          color="primary"
        />
      </Stack>
    )
  );
}

export default DoctorListPaginate;
