import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";

import Container from "@mui/material/Container";

import Button from "@mui/material/Button";

import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { logout } from "../../redux/actions/AuthAction";

const Header = () => {
  const history = useHistory();

  // Used For Action Calling
  const dispatch = useDispatch();

  // Get UserInfo From Reducer
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // Action For Logout
  const logoutHandler = () => {
    dispatch(logout());
  };

  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const MenuItem = ({ children, path, onClick }) => {
    return (
      <Box sx={{ display: "flex" }}>
        <Button
          onClick={() => {
            handleCloseNavMenu();

            if (path) {
              history.push(path);
            }
            if (onClick) {
              onClick();
            }
          }}
          sx={{ my: 2, color: "white", display: "block" }}
        >
          {children}
        </Button>
      </Box>
    );
  };

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          {/* <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ display: "flex" }}
          > */}
          <a href="/" className="navbar-brand">
            <img src="/static/images/free.png" width="32%" alt="" />
          </a>
          {/* Demo Consult
          </Typography> */}

          <MenuItem path="/">
            <i className="fas fa-home-lg-alt"></i> Home
          </MenuItem>

          {/* if User is Doctor */}
          {userInfo?.user_type === "Doctor" && (
            <MenuItem path="/doctor/consultList">Consult List</MenuItem>
          )}

          {/* if User is Patient */}
          {userInfo?.user_type === "Patient" && (
            <MenuItem path="/patient/consultList">Consult List</MenuItem>
          )}

          {userInfo?.user_type === "Patient" && (
            <MenuItem path="/consult">Make an appointment</MenuItem>
          )}

          {/* If No UserInfo */}
          {!userInfo ? (
            <MenuItem path="/userlogin">
              <i className="fas fa-user"></i> Login
            </MenuItem>
          ) : (
            <>
              <MenuItem path="/userprofile">
                <i className="fas fa-user-circle"></i>Profile
              </MenuItem>

              <MenuItem onClick={logoutHandler}>
                <i className="fas fa-user"></i>Logout
              </MenuItem>
            </>
          )}
        </Toolbar>
      </Container>
    </AppBar>
  );
};
export default Header;
