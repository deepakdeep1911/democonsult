/**
 * User Registration Page
 */

import React, { useState, useEffect, useRef } from "react";
import FormHelperText from "@mui/material/FormHelperText";
import { Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import DatePicker from "@mui/lab/DatePicker";
import { register, resetMessages } from "../../redux/actions/AuthAction";
import { AgeGroup } from "../../redux/actions/AgeAction";
import { language1 } from "../../redux/actions/LanguageAction";
import TextField from "@mui/material/TextField";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormGroup from "@mui/material/FormGroup";
import Checkbox from "@mui/material/Checkbox";
import { DialogActions } from "@mui/material";

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import Grid from "@mui/material/Grid";

import { Dialog } from "@mui/material";
import DialogTitle from "@mui/material/DialogTitle";
import Loader from "../../components/Loader/loader";
import moment from "moment";
import { validations } from "../../util";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  root: {
    "& .error": {
      color: theme.palette.error.main,
    },
  },
}));

function UserRegistration({ history }) {
  const classes = useStyles();

  const datePickerRef = useRef();
  // Set the state

  const [user_type, setUser_type] = useState("Patient");
  const [first_name, setFirstName] = useState("");
  const [last_name, setLastName] = useState("");
  const [gender, setGender] = useState("");
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState(null);
  const [selectedAge, setSelectedAge] = useState([]);
  const [phone_number, setPhoneNo] = useState();
  const [country, setCountry] = useState("India");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [selectedLanguages, setSelectedLanguages] = useState([]);
  const [expertise, setExpertise] = useState("");
  const [qualification, setQualification] = useState("");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [errors, setErrors] = useState({
    first_name: null,
    last_name: null,
    email: null,
    phone_number: null,
    city: null,
    dob: null,
    gender: null,
    state: null,
    age: null,

    languages: null,
    expertise: null,
    qualification: null,
    password: null,
    confirmPassword: null,
    message: null,
  });

  const dispatch = useDispatch();

  const { languages } = useSelector((state) => state.languageReducer);

  const { age } = useSelector((state) => state.AgeReducer);

  const userRegister = useSelector((state) => state.userRegisterReducer);
  const { error, loading, message } = userRegister;

  useEffect(() => {
    dispatch(language1());
    dispatch(AgeGroup());

    // if (userInfo) {
    //   alert("Registered Successful. Please Log In!");
    //   history.push("/");
    // }
  }, [history]);

  // language Handler
  const languagesHandler = (e) => {
    setErrors({ ...errors, languages: null });

    if (selectedLanguages.includes(e.target.value)) {
      // Language selected, unselect
      setSelectedLanguages(
        selectedLanguages.filter((value) => value !== e.target.value)
      );
    } else {
      // Language not selected, push
      setSelectedLanguages([...selectedLanguages, e.target.value]);
    }
  };

  // age Handler
  const agesHandler = (e) => {
    setErrors({ ...errors, age: null });
    if (selectedAge.includes(e.target.value)) {
      // Language selected, unselect
      setSelectedAge(selectedAge.filter((value) => value !== e.target.value));

      // const arrIndex = selectedLanguages.indexOf(e.target.value);
      // selectedLanguages.splice(arrIndex);
      // setSelectedLanguages([...selectedLanguages]);
    } else {
      // Language not selected, push
      setSelectedAge([...selectedAge, e.target.value]);
    }
  };
  /***
   * ClearField
   *
   */
  const clearFields = () => {
    setFirstName("");
    setLastName("");
    setGender("");
    setSelectedAge([]);
    setSelectedLanguages([]);
    setEmail("");
    setPhoneNo("");

    setState("");
    setCity("");
    setDob(null);
    setExpertise("");
    setQualification("");
    setPassword("");
    setConfirmPassword("");
  };
  const submitHandler = async () => {
    if (password !== confirmPassword) {
    } else {
      // Get User Details

      const success = await dispatch(
        register({
          first_name,
          last_name,
          gender,
          age: selectedAge,
          languages: selectedLanguages,
          email,
          phone_number,
          country,
          state,
          user_type,
          city,
          dob: moment(dob).format("YYYY-MM-DD"),
          expertise,
          qualification,
          password,
          confirmPassword,
        })
      );
      if (success) clearFields();
    }
  };

  const expertiseChoices = [
    "Audiologist",
    "Cardiologist",
    "Dentist",
    "ENT",
    "Gynaecologist",
    "Orthopaedic surgeon",
    "Paediatrician",
  ];

  const statechoice = [
    "Andaman and Nicobar Islands",
    "Andhra Pradesh",
    "Arunachal Pradesh ",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Lakshadweep",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "New Delhi",
    "Odisha",
    "Puducherry",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
  ];

  const genderchoice = ["Male", "Female", "Others"];

  const userTypechoice = ["Patient", "Doctor"];

  // errors Validations all fields
  const validateSubmit = (e) => {
    e.preventDefault();

    const tempErrors = {
      first_name: validations.firstName(first_name),
      last_name: validations.lastName(last_name),
      gender: validations.gender(gender),
      email: validations.email(email),
      city: validations.city(city),
      state: validations.state(state),
      languages: validations.Language(selectedLanguages),
      age: user_type === "Patient" ? null : validations.Age(selectedAge),

      expertise:
        user_type === "Patient" ? null : validations.expertise(expertise),

      qualification:
        user_type === "Patient"
          ? null
          : validations.qualification(qualification),

      phone_number: validations.phoneNumber(phone_number),
      dob: user_type === "Doctor" ? null : validations.dateOfBirth(dob),

      password: validations.password(password),
      confirmPassword: validations.confirmPassword(password, confirmPassword),
    };
    setErrors(tempErrors);

    if (Object.values(tempErrors).filter((value) => value).length) {
      console.log(
        "..values",
        Object.values(tempErrors).filter((value) => value)
      );
      return;
    }
    submitHandler();
  };

  return (
    <Grid
      className={classes.root}
      container
      spacing={0}
      alignItems="center"
      justifyContent="center"
      style={{ minHeight: "100vh" }}
    >
      <Grid item md={7}>
        <h1>REGISTER</h1>

        <div>
          {loading && <Loader />}

          <Dialog
            open={message || error}
            onClose={() => dispatch(resetMessages())}
          >
            <DialogTitle>
              {message && <p>{message}</p>}
              {error && <p>{error}</p>}
            </DialogTitle>

            <DialogActions>
              <Button onClick={() => dispatch(resetMessages())}>Ok</Button>
            </DialogActions>
          </Dialog>
        </div>
        <form onSubmit={validateSubmit} autoComplete="off">
          <FormControl>
            <FormLabel id="demo-radio-buttons-group-label">User Type</FormLabel>
            <RadioGroup
              row
              aria-labelledby="demo-radio-buttons-group-label"
              defaultValue="Patient"
              onChange={(e) => setUser_type(e.target.value)}
              value={user_type}
            >
              {userTypechoice.map((value) => (
                <FormControlLabel
                  value={value}
                  control={<Radio />}
                  label={value}
                />
              ))}
            </RadioGroup>
          </FormControl>

          <Grid container spacing={4}>
            <Grid item md={6}>
              <TextField
                label="First Name"
                error={!!errors.first_name}
                helperText={errors.first_name}
                variant="standard"
                value={first_name}
                onChange={(e) => {
                  setErrors({ ...errors, first_name: null });
                  setFirstName(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                label="Last Name"
                error={!!errors.last_name}
                helperText={errors.last_name}
                variant="standard"
                value={last_name}
                onChange={(e) => {
                  setErrors({ ...errors, last_name: null });
                  setLastName(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={12}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">Gender</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="gender"
                  value={gender}
                  label="gender"
                  error={!!errors.gender}
                  onChange={(e) => {
                    setErrors({ ...errors, gender: null });
                    setGender(e.target.value);
                  }}
                  variant="standard"
                  fullWidth
                >
                  {genderchoice.map((value, key) => (
                    <MenuItem key={value} value={value}>
                      {value}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormHelperText className="error">{errors.gender}</FormHelperText>
            </Grid>

            <Grid item md={12}>
              <TextField
                label="Country"
                error={!!errors.country}
                helperText={errors.country}
                variant="standard"
                value={country}
                disabled
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">State</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="state"
                  value={state}
                  error={!!errors.state}
                  label="state"
                  onChange={(e) => {
                    setErrors({ ...errors, state: null });
                    setState(e.target.value);
                  }}
                  fullWidth
                  variant="standard"
                >
                  {statechoice.map((value, key) => (
                    <MenuItem key={value} value={value}>
                      {value}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormHelperText className="error">{errors.state}</FormHelperText>
            </Grid>

            <Grid item md={6}>
              <TextField
                label="City"
                error={!!errors.city}
                helperText={errors.city}
                variant="standard"
                value={city}
                onChange={(e) => {
                  setErrors({ ...errors, city: null });
                  setCity(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={12}>
              <FormGroup>
                <InputLabel id="languages">Languages known</InputLabel>

                <FormControl error={!!errors.languages} variant="standard">
                  <FormGroup row>
                    {languages?.map(({ language_id, language_name }) => (
                      <FormControlLabel
                        key={language_id}
                        value={language_id}
                        control={<Checkbox />}
                        onClick={languagesHandler}
                        label={language_name}
                        id={`language_id${language_id}`}
                        checked={selectedLanguages.includes(
                          String(language_id)
                        )}
                      />
                    ))}
                  </FormGroup>
                  <FormHelperText>{errors.languages}</FormHelperText>
                </FormControl>
              </FormGroup>
            </Grid>

            {user_type === userTypechoice[1] && (
              <>
                <Grid item md={12}>
                  <InputLabel>Age Group</InputLabel>
                  <FormControl error={!!errors.age} variant="standard">
                    <FormGroup row>
                      {age?.map(({ age_id, age_min, age_max }) => (
                        <FormControlLabel
                          key={age_id}
                          value={age_id}
                          control={<Checkbox />}
                          onClick={agesHandler}
                          label={`(${age_min} - ${age_max}) years`}
                          id={`age_id ${age_id}`}
                          checked={selectedAge.includes(String(age_id))}
                        />
                      ))}
                    </FormGroup>
                    <FormHelperText>{errors.age}</FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item md={12}>
                  <FormControl fullWidth>
                    <InputLabel id="expertise">Speciality</InputLabel>
                    <Select
                      labelId="demo-simple-select-label"
                      id="expertise"
                      value={expertise}
                      error={!!errors.expertise}
                      label="expertise"
                      onChange={(e) => {
                        setErrors({ ...errors, expertise: null });
                        setExpertise(e.target.value);
                      }}
                      fullWidth
                      variant="standard"
                    >
                      {expertiseChoices.map((value, key) => (
                        <MenuItem key={value} value={value}>
                          {value}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormHelperText className="error">
                    {errors.expertise}
                  </FormHelperText>
                </Grid>

                <Grid item md={12}>
                  <TextField
                    label="Qualifications"
                    error={!!errors.qualification}
                    helperText={errors.qualification}
                    variant="standard"
                    value={qualification}
                    onChange={(e) => {
                      setErrors({ ...errors, qualification: null });
                      setQualification(e.target.value);
                    }}
                    fullWidth
                  />
                </Grid>
              </>
            )}
            <Grid item md={12}>
              {user_type === userTypechoice[0] && (
                <>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Date of birth"
                      value={dob}
                      // id="dob"

                      maxDate={new Date()}
                      // inputFormat="dd-mm-yyyy"
                      onChange={(value) => {
                        setErrors({ ...errors, dob: null });
                        setDob(value);
                      }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="standard"
                          error={!!errors.dob}
                          helperText={errors.dob}
                          fullWidth
                        />
                      )}
                    />
                  </LocalizationProvider>
                </>
              )}
            </Grid>
            <Grid item md={6}>
              <TextField
                label="Phone Number"
                error={!!errors.phone_number}
                helperText={errors.phone_number}
                type="text"
                variant="standard"
                value={phone_number}
                onChange={(e) => {
                  setErrors({ ...errors, phone_number: null });
                  setPhoneNo(e.target.value.replace(/[^0-9+]/g, ""));
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                label="Email"
                error={!!errors.email}
                helperText={errors.email}
                type="text"
                variant="standard"
                value={email}
                onChange={(e) => {
                  setErrors({ ...errors, email: null });
                  setEmail(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                label="Password"
                error={!!errors.password}
                helperText={errors.password}
                type="password"
                variant="standard"
                value={password}
                onChange={(e) => {
                  setErrors({ ...errors, password: null });
                  setPassword(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                label="Confirm Password"
                error={!!errors.confirmPassword}
                helperText={errors.confirmPassword}
                type="password"
                variant="standard"
                value={confirmPassword}
                onChange={(e) => {
                  setErrors({ ...errors, confirmPassword: null });
                  setConfirmPassword(e.target.value);
                }}
                fullWidth
              />
            </Grid>
          </Grid>

          <Box style={{ marginTop: 40 }}>
            <Button type="submit" className="form-control" variant="primary">
              Register
            </Button>
          </Box>
        </form>
      </Grid>
    </Grid>
  );
}
export default UserRegistration;
