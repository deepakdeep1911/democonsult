/**
 * This is HomePage
 */

import React from "react";

const Home = () => {
  return (
    <div className="container">
      <section id="about">
        <div className="container">
          <div className="row">
            <div className="col-md-6 col-sm-6">
              <div className="about-info">
                <h2 className="wow fadeInUp" data-wow-delay="0.6s">
                  Welcome to Your Consult Medic
                </h2>
                <div className="wow fadeInUp" data-wow-delay="0.8s">
                  <p>
                    Technology becomes helpful when the people behind it are
                    solving human challenges. Meet our team of health and
                    technology experts who are breaking down barriers to care.
                  </p>
                  <p>
                    Conduct patient risk assessments to inform population health
                    management activities.
                  </p>
                </div>
                {/* <figure className="profile wow fadeInUp" data-wow-delay="1s">
                                   <img src="/static/images/author-image.jpg" className="img-responsive" alt=""/>
                                   <figcaption>
                                        <h3>Dr. Neil Jackson</h3>
                                        <p>General Principal</p>
                                   </figcaption>
                              </figure> */}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
