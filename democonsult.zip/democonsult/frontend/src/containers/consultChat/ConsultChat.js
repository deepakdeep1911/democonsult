/**
 * This is the Consult-Chat Page
 */

import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { addChat, chatListConsults } from "../../redux/actions/ChatAction";
import axios from "axios";
import { Box } from "@mui/system";
import { Grid, TextField } from "@mui/material";
import { makeStyles } from "@mui/styles";
import SendIcon from "@mui/icons-material/Send";

const useStyles = makeStyles({
  root: {
    "& .cdsf": {
      backgroundColor: "red",
    },
  },
});

const ConsultChat = ({ match, history, location }) => {
  const { otherUserName } = location.state;

  const classes = useStyles();

  // Dispatch For Calling Action
  const dispatch = useDispatch();

  //Get Details From Reducer
  const chatList = useSelector((state) => state.chatListReducer);
  const { chat } = chatList;

  //Get Details From Reducer
  const [message, setMessage] = useState("");

  const consult_id = match.params.consult_id;

  //Get Details From Reducer
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  //Get Details From Reducer
  let id = userInfo?.id;

  useEffect(() => {
    if (!userInfo) {
      history.push("/");
    } else {
      dispatch(chatListConsults(consult_id));
    }
  }, [dispatch, history]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!message) {
      return;
    }
    let formField = new FormData();

    formField.append("message", message);
    formField.append("consult_id", consult_id);

    try {
      const { data } = await axios({
        method: "post",
        url: "http://192.168.1.190:8000/chat/",
        // url: "http://localhost:3000/chat/",

        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${userInfo?.token}`,
        },

        data: formField,
      });

      dispatch(addChat(data));
      setMessage("");
    } catch (error) {
      console.error("Error in sending chat message", error);
    }
  };

  return (
    <Box className={classes.root}>
      <div style={{ marginLeft: 90 }}>
        <div
          style={{
            width: "800px",

            display: "flex",
            flexDirection: "column",
            padding: 15,
            borderRadius: 10,
            border: "4px solid lightgray",
          }}
        >
          <h1 style={{ textAlign: "center", color: "green" }}>
            {otherUserName}
          </h1>
          <Grid container>
            <Grid
              item
              xs={12}
              style={{
                display: "flex",
                flexDirection: "column",
                height: "70vh",
                overflowY: "scroll",
              }}
            >
              {chat?.map((chat) => {
                const isMe = id === chat.sender_id;

                return (
                  <div
                    key={chat.message_id}
                    style={{
                      alignSelf: isMe ? "flex-end" : "flex-start",
                      marginBottom: 18,
                    }}
                  >
                    <div
                      key={chat.message_id}
                      style={{
                        borderRadius: 12,
                        backgroundColor: isMe ? "#90EE90" : " #D3D3D3",
                        padding: 8,
                      }}
                    >
                      <div>{chat.first_name}</div>
                      <div>{chat.message}</div>
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        color: "#888",
                        textAlign: "end",
                        marginTop: 3,
                      }}
                    >
                      {moment(chat.created_at).format("DD MMM YYYY hh:mm a")}
                    </div>
                  </div>
                );
              })}
            </Grid>
            <Grid item xs={12}>
              <Form onSubmit={handleSubmit} style={{ alignSelf: "flex-end" }}>
                <Box display="flex" justifyContent="flex-end">
                  <TextField
                    label="Write something..."
                    variant="standard"
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    fullWidth
                  />

                  <Button type="submit" variant="primary">
                    <SendIcon />
                  </Button>
                </Box>
              </Form>
            </Grid>
          </Grid>
        </div>
      </div>
    </Box>
  );
};

export default ConsultChat;
