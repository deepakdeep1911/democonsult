/**
 * This is Profile inThis Update Profile & GetProfile from LoginUser(Doctor & Patient)
 */

import React, { useState, useEffect } from "react";

import { useSelector, useDispatch } from "react-redux";
import { USER_UPDATE_PROFILE_RESET } from "../../constants/userConstants";
import { Link } from "react-router-dom";

import TextField from "@mui/material/TextField";
import DatePicker from "@mui/lab/DatePicker";

import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";

import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormGroup from "@mui/material/FormGroup";
import Checkbox from "@mui/material/Checkbox";

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import Grid from "@mui/material/Grid";
import { Button } from "react-bootstrap";

import FormHelperText from "@mui/material/FormHelperText";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";

import DialogTitle from "@mui/material/DialogTitle";
import {
  getUserDetails,
  updateUserProfile,
} from "../../redux/actions/AuthAction";
import { language1 } from "../../redux/actions/LanguageAction";
import { AgeGroup } from "../../redux/actions/AgeAction";
import { validations } from "../../util";
import moment from "moment";

const Profile = ({ history }) => {
  /**
   * Set State
   */

  const [first_name, setFirst_Name] = useState("");
  const [last_name, setLast_Name] = useState("");
  const [email, setEmail] = useState("");
  const [phone_number, setPhone_no] = useState("");
  const [country, setCountry] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [dob, setDob] = useState(new Date());
  const [selectedAge, setSelectedAge] = useState([]);
  const [expertise, setExpertise] = useState("");
  const [qualification, setQualification] = useState("");
  const [submittedDialogOpen, setSubmittedDialogOpen] = useState(false);

  const [selectedLanguages, setSelectedLanguages] = useState([]);

  const [errors, setErrors] = useState({
    first_name: null,
    last_name: null,
    email: null,
    phone_number: null,
    city: null,
    expertise: null,
    qualification: null,
    password: null,
    age: null,
    selectedAge: null,
    languages: null,
    confirmPassword: null,
    message: null,
  });

  /**
   * Fetch the data From Reducer
   */
  const dispatch = useDispatch();

  const userDetails = useSelector((state) => state.userDetailsReducer);
  const { user } = userDetails;
  const { user_type } = user;

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const { languages } = useSelector((state) => state.languageReducer);

  const { age } = useSelector((state) => state.AgeReducer);

  useEffect(() => {
    if (!user) return;
    setFirst_Name(user.first_name);
    setLast_Name(user.last_name);
    setEmail(user.email);
    setPhone_no(user.phone_number);
    setCountry(user.country);
    setState(user.state);

    setDob(user.dob ?? []);
    setCity(user.city);
    setSelectedAge(user.age ?? []);
    setExpertise(user.expertise);
    setQualification(user.qualification);
    setSelectedLanguages(user.languages ?? []);
  }, [user]);

  useEffect(() => {
    dispatch({ type: USER_UPDATE_PROFILE_RESET });
    dispatch(getUserDetails(userInfo.id));
    dispatch(language1());
    dispatch(AgeGroup());
  }, [dispatch]);

  const languagesHandler = (e) => {
    setErrors({ ...errors, languages: null });
    const id = Number(e.target.value);
    if (!id) {
      return;
    }

    if (selectedLanguages.includes(id)) {
      // Language selected, unselect
      setSelectedLanguages(selectedLanguages.filter((value) => value !== id));
    } else {
      // Language not selected, push
      setSelectedLanguages([...selectedLanguages, id]);
    }
  };

  const agesHandler = (e) => {
    setErrors({ ...errors, age: null });
    const id = Number(e.target.value);
    if (!id) {
      return;
    }

    if (selectedAge.includes(id)) {
      // Language selected, unselect
      setSelectedAge(selectedAge.filter((value) => value !== id));

      // const arrIndex = selectedLanguages.indexOf(e.target.value);
      // selectedLanguages.splice(arrIndex);
      // setSelectedLanguages([...selectedLanguages]);
    } else {
      // Language not selected, push
      setSelectedAge([...selectedAge, id]);
    }
  };
  const submitHandler = async () => {
    const status = await dispatch(
      updateUserProfile({
        id: user.user_id,
        first_name: first_name,
        last_name: last_name,
        email: email,
        phone_number: phone_number,
        country: country,
        state: state,
        city: city,

        dob: moment(dob).format("YYYY-MM-DD"),

        age: selectedAge,
        selectedAge: selectedAge,
        languages: selectedLanguages,
        expertise: expertise,
        qualification: qualification,

        // password: password,
      })
    );

    if (status) {
      setSubmittedDialogOpen(true);
    }
  };

  const validateSubmit = (e) => {
    e.preventDefault();

    const tempErrors = {
      first_name: validations.firstName(first_name),
      last_name: validations.lastName(last_name),
      email: validations.email(email),
      city: validations.city(city),

      phone_number: validations.phoneNumber(phone_number),
      dob: user_type === "Doctor" ? null : validations.dateOfBirth(dob),
      expertise:
        user_type === "Patient" ? null : validations.expertise(expertise),

      qualification:
        user_type === "Patient"
          ? null
          : validations.qualification(qualification),

      age: user_type === "Patient" ? null : validations.Age(selectedAge),
      languages: validations.Language(selectedLanguages),
      // password:validations.password(password),
      // confirmPassword:validations.confirmPassword(password,confirmPassword)
    };

    setErrors(tempErrors);

    if (Object.values(tempErrors).filter((value) => value).length) {
      console.log(
        "..values",
        Object.values(tempErrors).filter((value) => value)
      );
      return;
    }

    submitHandler();
  };

  // state Choices
  const statechoice = [
    "Andaman and Nicobar Islands",
    "Andhra Pradesh",
    "Arunachal Pradesh ",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Lakshadweep",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "New Delhi",
    "Odisha",
    "Puducherry",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
  ];

  // expertise choices
  const expertiseChoices = [
    "Cardiologist",
    "Audiologist",
    "Dentist",
    "ENT",
    "Gynaecologist",
    "Orthopaedic surgeon",
    "Paediatrician",
  ];

  return (
    <Grid container spacing={0} alignItems="center" justifyContent="center">
      <Grid item md={7}>
        <Dialog
          open={submittedDialogOpen}
          onClose={() => setSubmittedDialogOpen(false)}
        >
          <DialogTitle>Your profile has been updated successfully.</DialogTitle>
          <DialogActions>
            <Button onClick={() => setSubmittedDialogOpen(false)}>Ok</Button>
          </DialogActions>
        </Dialog>
        <h3>USER PROFILE</h3>
        <br />

        <div></div>
        <form onSubmit={validateSubmit} autoComplete="off">
          <Grid container spacing={4}>
            <Grid item md={6}>
              <TextField
                error={!!errors.first_name}
                helperText={errors.first_name}
                label="First Name"
                variant="standard"
                value={first_name}
                onChange={(e) => {
                  setErrors({ ...errors, first_name: null });
                  setFirst_Name(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.last_name}
                helperText={errors.last_name}
                label="Last Name"
                variant="standard"
                value={last_name}
                onChange={(e) => {
                  setErrors({ ...errors, last_name: null });
                  setLast_Name(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.email}
                helperText={errors.email}
                label="Email"
                type="text"
                variant="standard"
                value={email}
                onChange={(e) => {
                  setErrors({ ...errors, email: null });
                  setEmail(e.target.value);
                }}
                fullWidth
              />
            </Grid>
            <Grid item md={6}>
              <TextField
                error={!!errors.phone_number}
                helperText={errors.phone_number}
                label="Phone Number"
                type="text"
                variant="standard"
                value={phone_number}
                onChange={(e) => {
                  setErrors({ ...errors, phone_number: null });
                  setPhone_no(e.target.value.replace(/[^0-9+]/g, ""));
                }}
                fullWidth
              />
            </Grid>
            <Grid item md={12}>
              <TextField
                label="Country"
                variant="standard"
                value={country}
                disabled
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">State</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="state"
                  value={state}
                  label="state"
                  onChange={(e) => {
                    setErrors({ ...errors, state: null });
                    setState(e.target.value);
                  }}
                  fullWidth
                  variant="standard"
                >
                  {statechoice.map((value, key) => (
                    <MenuItem key={value} value={value}>
                      {value}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item md={6}>
              <TextField
                error={!!errors.city}
                helperText={errors.city}
                label="City"
                variant="standard"
                value={city}
                onChange={(e) => {
                  setErrors({ ...errors, city: null });
                  setCity(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={12}>
              <FormGroup>
                <InputLabel id="languages">Languages known</InputLabel>

                <FormControl error={!!errors.languages} variant="standard">
                  <FormGroup row>
                    {languages?.map(({ language_id, language_name }) => (
                      <FormControlLabel
                        key={language_id}
                        value={language_id}
                        control={<Checkbox />}
                        onClick={languagesHandler}
                        label={language_name}
                        id={`language_id${language_id}`}
                        checked={selectedLanguages.includes(language_id)}
                      />
                    ))}
                  </FormGroup>
                  <FormHelperText>{errors.languages}</FormHelperText>
                </FormControl>
              </FormGroup>
            </Grid>

            {userInfo?.user_type === "Doctor" && (
              <>
                <Grid item md={12}>
                  <InputLabel>Age Group</InputLabel>
                  <FormControl error={!!errors.age} variant="standard">
                    <FormGroup row>
                      {age?.map(({ age_id, age_min, age_max }) => (
                        <FormControlLabel
                          key={age_id}
                          value={age_id}
                          control={<Checkbox />}
                          onClick={agesHandler}
                          label={`(${age_min} - ${age_max}) years`}
                          id={`age_id ${age_id}`}
                          checked={selectedAge.includes(age_id)}
                        />
                      ))}
                    </FormGroup>
                    <FormHelperText>{errors.age}</FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item md={12}>
                  <FormControl fullWidth>
                    <InputLabel id="expertise">Speciality</InputLabel>
                    <Select
                      labelId="demo-simple-select-label"
                      id="expertise"
                      value={expertise}
                      label="expertise"
                      onChange={(e) => {
                        setErrors({ ...errors, expertise: null });
                        setExpertise(e.target.value);
                      }}
                      fullWidth
                      variant="standard"
                    >
                      {expertiseChoices.map((value, key) => (
                        <MenuItem key={value} value={value}>
                          {value}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item md={12}>
                  <TextField
                    error={!!errors.qualification}
                    helperText={errors.qualification}
                    label="Qualifications"
                    variant="standard"
                    value={qualification}
                    onChange={(e) => {
                      setErrors({ ...errors, qualification: null });
                      setQualification(e.target.value);
                    }}
                    fullWidth
                  />
                </Grid>
              </>
            )}
            <Grid item md={12}>
              {userInfo?.user_type === "Patient" && (
                <>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Date of birth"
                      value={dob}
                      id="dob"
                      inputFormat="dd-MM-yyyy"
                      maxDate={new Date()}
                      onChange={(value) => {
                        setErrors({ ...errors, dob: null });
                        setDob(value);
                      }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="standard"
                          error={!!errors.dob}
                          helperText={errors.dob}
                          fullWidth
                        />
                      )}
                    />
                  </LocalizationProvider>
                </>
              )}
            </Grid>

            <Grid md={12} paddingTop={2}>
              <Box display="flex " justifyContent="flex-end">
                <Link to="/change/password">Change password</Link>
              </Box>
            </Grid>
          </Grid>

          <Box style={{ marginTop: 40 }}>
            <Button type="submit" className="form-control" variant="primary">
              Update
            </Button>
          </Box>
        </form>
      </Grid>
    </Grid>
  );
};

export default Profile;
