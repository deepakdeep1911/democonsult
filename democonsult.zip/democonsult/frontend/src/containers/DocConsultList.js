/**
 * Consult List for Doctor
 */

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Loader from "../components/Loader/loader";
import Message from "../components/Message/Message";
import { listDocConsults } from "../redux/actions/ConsultAction";
import { Link } from "react-router-dom";
import axios from "axios";
import queryString from "querystring";
import DoctorListPaginate from "../components/DoctorListPaginate";
import {
  IconArrowNarrowUp,
  IconArrowNarrowDown,
  IconMessage,
  IconCircleX,
  IconCheckbox,
} from "@tabler/icons";
import moment from "moment";
import { modifyList } from "../redux/actions/ConsultAction";
import swal from "sweetalert";

export default function DocConsultList({ history, location }) {
  // dispatch for using action
  const dispatch = useDispatch();

  // get details for state
  const docConsultListReducer = useSelector((state) => state.docConsultList);
  const { consults, loading, error, pages } = docConsultListReducer;

  // get userInfo from state
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // columns to map
  const columns = [
    { title: "ID", field: "consult_id" },
    { title: "Name", field: "first_name" },
    { title: "Email", field: "email" },
    { title: "DOB", field: "dob" },
    { title: "Preferred Time", field: "preferred_time" },
    { title: "Consult Created", field: "createdAt" },
    { title: "Approve" },
    { title: "Conversation" },
  ];

  // initialize page variable for replacing "?" with "" in url when page changes
  const { page } = queryString.parse(location.search?.replace("?", ""));

  // initialize the variables
  const [sortBy, setSortBy] = useState("consult_id");
  const [sortOrder, setSortOrder] = useState("asc");

  // sorting
  const handleSort = (field, order = "asc") => {
    setSortBy(field);
    setSortOrder(order);
  };

  // handleAccept function
  const handleAccept = async (consult_id) => {
    const { data } = await axios.put(
      `http://192.168.1.190:8000/doctoraccept/${consult_id}/`,
      // `http://localhost:3000/doctoraccept/${consult_id}/`,
      {},

      {
        // send userInfo with request
        headers: {
          Authorization: `Bearer ${userInfo?.token}`,
        },
      }
    );

    // append the changes to the list
    dispatch(modifyList(data));

    swal("Consult Accepted", "success");
  };

  // handleReject function
  const handleReject = async (consult_id) => {
    const { data } = await axios.put(
      `http://192.168.1.190:8000/doctorwithdraw/${consult_id}/`,
      // `http://localhost:3000/doctorwithdraw/${consult_id}/`,
      {},
      {
        // send userInfo with request
        headers: {
          Authorization: `Bearer ${userInfo?.token}`,
        },
      }
      // append the changes to the list
      // dispatch(modifyList(consult_id))
    );

    dispatch(modifyList(data));
    swal("Consult Rejected", "info");
  };

  useEffect(() => {
    // if user is logged in
    if (userInfo) {
      dispatch(listDocConsults({ sortBy, sortOrder, page }));
    }
    // if no user is logged in
    else {
      history.push("/userlogin");
    }
  }, [dispatch, history, userInfo, sortBy, sortOrder, page]);

  // function used in consult id
  function pad(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
  }

  return (
    <div className="container">
      <h1>Consults</h1>

      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : (
        // Table
        <table
          className="table table-striped table-bordered table-sm"
          cellSpacing="0"
          width="100%"
        >
          <thead>
            <tr>
              {/* mapping columns as follows */}
              {columns.map(({ title, field }) => {
                return (
                  <th key={title}>
                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <div style={{ marginRight: 5 }}>{title}</div>
                      {field && (
                        <>
                          {/* sorting */}
                          <IconArrowNarrowUp
                            onClick={() => handleSort(field, "asc")}
                            size={18}
                            style={{
                              cursor: "pointer",
                              color:
                                sortBy === field && sortOrder === "asc"
                                  ? "red"
                                  : "black",
                            }}
                          />

                          <IconArrowNarrowDown
                            onClick={() => handleSort(field, "desc")}
                            size={18}
                            style={{
                              cursor: "pointer",
                              color:
                                sortBy === field && sortOrder === "desc"
                                  ? "red"
                                  : "black",
                            }}
                          />
                        </>
                      )}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {/* mapping consults */}
            {consults?.map((consult) => (
              <tr key={consult.consult_id}>
                <td>Consult-{pad(consult.consult_id, 3)}</td>
                <td>{consult.first_name}</td>
                <td>{consult.email}</td>
                {/* format using moment.js */}
                <td>{moment(consult.dob).format("MMM DD, YYYY")}</td>
                <td>
                  <b>
                    {moment(consult.preferred_time).format("MMM DD, YYYY ")}
                  </b>
                  {moment(consult.preferred_time).format("hh:mm a")}
                </td>
                <td>
                  {moment(consult.createdAt).format("YYYY-MM-DD hh:mm a")}
                </td>

                {(consult.consult_status === "Active" ||
                  consult.consult_status === "Approved") && (
                  <>
                    <td>
                      {/* Consult accept button */}
                      {consult?.accepted_doctor_id !== userInfo.id ? (
                        <span
                          style={{ cursor: "pointer", color: "green" }}
                          onClick={() => handleAccept(consult.consult_id)}
                        >
                          <IconCheckbox /> Accept
                        </span>
                      ) : (
                        // Consult withdraw button
                        <span
                          style={{ cursor: "pointer", color: "red" }}
                          onClick={() => handleReject(consult.consult_id)}
                        >
                          <IconCircleX /> Withdraw
                        </span>
                      )}
                    </td>

                    {/* Chat button */}
                    {consult?.accepted_doctor_id === userInfo.id && (
                      <td>
                        <Link
                          style={{ textDecoration: "none" }}
                          to={{
                            pathname: `/message/${consult.consult_id}`,
                            state: { otherUserName: consult.first_name },
                          }}
                        >
                          Chat
                          <IconMessage />
                        </Link>
                      </td>
                    )}
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {/* {consults?.length === 0 && <h4>No consults available</h4>} */}

      {/* Pagination */}
      <DoctorListPaginate pages={pages} page={page} />
    </div>
  );
}
