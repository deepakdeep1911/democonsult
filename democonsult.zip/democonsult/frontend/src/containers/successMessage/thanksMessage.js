// This is the Success Message Page After Activate the Account
import { React, useEffect } from "react";
import { Link } from "react-router-dom";
import { useSearchParam } from "react-use";
import { useDispatch } from "react-redux";
import { activateAccount } from "../../redux/actions/AuthAction";
const Thanks = () => {
  const dispatch = useDispatch();
  const uid = useSearchParam("uid");
  const token = useSearchParam("token");
  const message1 = "Success";
  useEffect(() => {
    if (uid && token) {
      dispatch(activateAccount(uid, token));
      return message1;
    }
  }, []);
  return (
    <div>
      <h4>
        Your Account has been activated <br />
        <Link to="/userlogin">Click here to login</Link>
      </h4>
    </div>
  );
};
export default Thanks;
