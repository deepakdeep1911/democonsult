/**
 * This is Consult Submit Form By the Patient
 */

import TextField from "@mui/material/TextField";
import DatePicker from "@mui/lab/DatePicker";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";

import Box from "@mui/material/Box";

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import Grid from "@mui/material/Grid";

import DateTimePicker from "@mui/lab/DateTimePicker";
import React, { useState, useEffect } from "react";

import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import { getUserDetails } from "../../redux/actions/AuthAction";
import moment from "moment";
import { validations } from "../../util";

import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";

import DialogTitle from "@mui/material/DialogTitle";

const ConsultForm = ({ history }) => {
  // Set the state
  const [first_name, setFirst_Name] = useState("");
  const [last_name, setLast_Name] = useState("");
  const [email, setEmail] = useState("");
  const [phone_number, setPhone_number] = useState("");
  const [country, setCountry] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [dob, setDob] = useState("");
  const [preferred_time, setPreferred_time] = useState(null);
  const [errors, setErrors] = useState({
    first_name: null,
    last_name: null,
    email: null,
    dob: null,
    phone_number: null,
    city: null,
    preferred_time: null,
    message: null,
  });
  const [submittedDialogOpen, setSubmittedDialogOpen] = useState(false);

  const statechoice = [
    "Andaman and Nicobar Islands",
    "Andhra Pradesh",
    "Arunachal Pradesh ",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Lakshadweep",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "New Delhi",
    "Odisha",
    "Puducherry",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
  ];

  // Dispatch used For Calling Action
  const dispatch = useDispatch();

  // Get Details From Reducer
  const userDetails = useSelector((state) => state.userDetailsReducer);
  const { user } = userDetails;

  // Get Details From Reducer
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  /***
   * ClearField
   *
   */
  const clearFields = () => {
    setFirst_Name("");
    setLast_Name("");
    setEmail("");
    setPhone_number("");
    setCountry("");
    setState("");
    setCity("");
    setDob("");
    setPreferred_time("");
  };

  useEffect(() => {
    // If No userInfo Redirect To Login page
    if (!userInfo) {
      history.push("/userlogin");
    } else {
      // UserInfo
      if (!user || !user.first_name || userInfo.user_id !== user.user_id) {
        dispatch(getUserDetails(userInfo.id));
      } else {
        // Get userInfo From Reducer
        setFirst_Name(user.first_name);
        setLast_Name(user.last_name);
        setEmail(user.email);
        setPhone_number(user.phone_number);
        setCountry(user.country);
        setState(user.state);
        setDob(user.dob);
        setCity(user.city);
      }
    }
  }, [dispatch, history, userInfo, user]);
  /***
   * Submit Consult Details By the Patient
   */
  const detailsSubmit = async () => {
    let formField = new FormData();
    formField.append("first_name", first_name);
    formField.append("last_name", last_name);
    formField.append("email", email);
    formField.append("phone_number", phone_number);
    formField.append("country", country);
    formField.append("state", state);
    formField.append("city", city);
    formField.append("dob", moment(dob).format("YYYY-MM-DD"));
    formField.append(
      "preferred_time",
      moment(preferred_time).format("YYYY-MM-DD hh:mm")
    );
    await axios({
      method: "post",
      url: "http://192.168.1.190:8000/consult/form",
      // url: "http://127.0.0.1:8000/consult/form",

      headers: {
        Authorization: `Bearer ${userInfo?.token}`,
      },
      data: formField,
    }).then((response) => {
      setSubmittedDialogOpen(true);
    });
    clearFields();
  };

  const validateSubmit = (e) => {
    e.preventDefault();

    const tempErrors = {
      first_name: validations.firstName(first_name),
      last_name: validations.lastName(last_name),
      email: validations.email(email),
      city: validations.city(city),
      preferred_time: validations.prefferedDateTime(preferred_time),
      phone_number: validations.phoneNumber(phone_number),
      dob: validations.dateOfBirth(dob),
    };

    setErrors(tempErrors);

    if (Object.values(tempErrors).filter((value) => value).length) {
      console.log(
        "..values",
        Object.values(tempErrors).filter((value) => value)
      );
      return;
    }
    detailsSubmit();
  };
  return (
    <Grid container spacing={0} alignItems="center" justifyContent="center">
      <Dialog
        open={submittedDialogOpen}
        onClose={() => history.push("/patient/consultList")}
      >
        <DialogTitle>Your consult has been submitted successfully.</DialogTitle>
        <DialogActions>
          <Button onClick={() => history.push("/patient/consultList")}>
            Go to Consult List
          </Button>
        </DialogActions>
      </Dialog>

      <Grid item md={7}>
        <h1>MAKE AN APPOINTMENT</h1>
        {/* {message && <Message variant="danger">{message}</Message>}
        {error && <Message variant="danger">{error}</Message>}
        {loading && <Loader />} */}

        <div></div>
        <form onSubmit={validateSubmit} autoComplete="off">
          <Grid container spacing={4}>
            <Grid item md={6}>
              <TextField
                error={!!errors.first_name}
                helperText={errors.first_name}
                variant="standard"
                label="First Name"
                value={first_name}
                onChange={(e) => {
                  setErrors({ ...errors, first_name: null });
                  setFirst_Name(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.last_name}
                helperText={errors.last_name}
                label="Last Name"
                variant="standard"
                value={last_name}
                onChange={(e) => {
                  setErrors({ ...errors, last_name: null });
                  setLast_Name(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.email}
                helperText={errors.email}
                label="Email"
                type="text"
                variant="standard"
                value={email}
                onChange={(e) => {
                  setErrors({ ...errors, email: null });
                  setEmail(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.phone_number}
                helperText={errors.phone_number}
                label="Phone Number"
                type="text"
                variant="standard"
                value={phone_number}
                onChange={(e) => {
                  setErrors({ ...errors, phone_number: null });
                  setPhone_number(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={12}>
              <TextField
                label="Country"
                variant="standard"
                value={country}
                disabled
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">State</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="state"
                  value={state}
                  label="state"
                  onChange={(e) => {
                    setErrors({ ...errors, state: null });
                    setState(e.target.value);
                  }}
                  fullWidth
                  variant="standard"
                >
                  {statechoice.map((value, key) => (
                    <MenuItem key={value} value={value}>
                      {value}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item md={6}>
              <TextField
                error={!!errors.city}
                helperText={errors.city}
                label="City"
                variant="standard"
                value={city}
                onChange={(e) => {
                  setErrors({ ...errors, city: null });
                  setCity(e.target.value);
                }}
                fullWidth
              />
            </Grid>

            <Grid item md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date of birth"
                  value={dob}
                  id="dob"
                  maxDate={new Date()}
                  onChange={(value) => {
                    setErrors({ ...errors, dob: null });
                    setDob(value);
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      variant="standard"
                      error={!!errors.dob}
                      helperText={errors.dob}
                      fullWidth
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DateTimePicker
                  label="Preferred Date & Time"
                  value={preferred_time}
                  id="preferred_time"
                  variant="standard"
                  minDateTime={new Date()}
                  onChange={(value) => {
                    setErrors({ ...errors, preferred_time: null });
                    setPreferred_time(value);
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      variant="standard"
                      error={!!errors.preferred_time}
                      helperText={errors.preferred_time}
                      fullWidth
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
          </Grid>
          <Box style={{ marginTop: 40 }}>
            <Button type="submit" className="form-control" variant="contained">
              Book
            </Button>
          </Box>
        </form>
      </Grid>
    </Grid>
  );
};
export default ConsultForm;
