from . models import CustomUser, Consult_table, Language_table, Age_group_table, Message_table

from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import serializers


class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ["id", "username", "is_active", "date_joined", "first_name", "last_name",
                  "gender", "email", "phone_number", "country", "state", "city", "dob", "expertise", "qualification",
                  "user_type", "user_status", "created_at", "languages", "age"]

    def get__id(self, obj):
        return obj.id


class CustomUserMinimalSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ["id", "first_name", "last_name"]

    def get__id(self, obj):
        return obj.id


class UserSerializerWithToken(CustomUserSerializer):
    token = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = CustomUser
        fields = [
            "id",
            "first_name",
            "last_name",
            "username",
            "gender",
            "email",
            "phone_number",
            "country",
            "state",
            "city",
            "languages",
            "age",
            "dob",
            "expertise",
            "qualification",
            "user_type",
            "user_status",
            'token'
        ]

    def get_token(self, obj):
        token = RefreshToken.for_user(obj)
        return str(token.access_token)


# Consult table serializer
class ConsultTableSerializer(serializers.ModelSerializer):
    doctor = CustomUserMinimalSerializer(
        source='accepted_doctor_id', read_only=True)

    class Meta:
        model = Consult_table
        fields = '__all__'


class Language_serializer(serializers.ModelSerializer):
    class Meta:
        model = Language_table
        fields = "__all__"


class Agegroup_serializer(serializers.ModelSerializer):
    class Meta:
        model = Age_group_table
        fields = "__all__"


class Message_serializer(serializers.ModelSerializer):
    sender = CustomUserMinimalSerializer(source='sender_id', read_only=True)
    recipient = CustomUserMinimalSerializer(
        source='recipient_id', read_only=True)

    class Meta:
        model = Message_table
        fields = ["message_id", "message_type", "message", "file_name", "created_at",
                  "consult_id",
                  "sender_id",
                  "recipient_id", "sender", "recipient"
                  ]
