# from django.db.models.signals import pre_save
# from .models import User_table
# from django.contrib.auth.models import User


# # Configuring the email as username
# # (Also make sure to change the settings in apps.py)
# def updateUser(sender, instance, **kwargs):
#     # print('Signal updateUser')
#     user = instance
#     if user.email != '':
#         user.username = user.email


# pre_save.connect(updateUser, sender=User_table)
