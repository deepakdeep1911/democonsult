from datetime import date
from consultapp.serializers import ConsultTableSerializer
from consultapp.models import Consult_table, CustomUser
from django.db.models import Q
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Consult Form Details
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def consult(request):
    data = request.data

    print('preff', data['preferred_time'])
    try:
        user = Consult_table.objects.create(

            patient_id=request.user,
            first_name=data['first_name'],

            last_name=data['last_name'],
            email=data['email'],
            phone_number=data['phone_number'],
            country=data['country'],
            state=data['state'],
            city=data['city'],
            dob=data['dob'],
            preferred_time=data['preferred_time']

        )

        serializer = ConsultTableSerializer(user, many=False)
        return Response(serializer.data)
    except Exception as e:
        print(e)
        return Response({'detail': 'Something went wrong'}, status=status.HTTP_400_BAD_REQUEST)


# Usertable Views
def calculate_age(born):
    if not born:
        return 0
    today = date.today()
    return today.year - born.year - ((today.month, today.day) < (born.month, born.day))


# Consult Chat
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def docConsultList(request):

    # sortBy and sortOrder
    sortBy = request.query_params.get('sortBy', 'consult_id')
    sortOrder = request.query_params.get('sortOrder', 'asc')
    if sortOrder != 'asc':
        sortBy = '-' + sortBy

    user = request.user
    ages = []
    for age in user.age.all():
        ages.extend(list(range(age.age_min, age.age_max + 1)))

    # Filter Data by Language & Age
    consults = Consult_table.objects.filter(
        Q(consult_status='Approved', accepted_doctor_id=None) | Q(
            accepted_doctor_id=user.id),
        patient_id__in=[q.id for q in CustomUser.objects.filter(languages__in=user.languages.all())]).order_by(sortBy)

    new_consults = []
    for consult in consults:
        if calculate_age(consult.dob) in ages:
            new_consults.append(consult)

    # For Pagination
    page = request.query_params.get('page')
    # Paginator in this case takes in new_consults we want to paginage, and number means how many should come up on one page
    paginator = Paginator(new_consults, 5)

    try:
        # if we pass in a page, 'paginator' and 'page' is defined above
        new_consults = paginator.page(page)
    except PageNotAnInteger:
        # when we have not clicked on a page, means we are on page 1
        new_consults = paginator.page(1)
    except EmptyPage:
        # If we have am empty page (meaning the page has no products)
        new_consults = paginator.page(paginator.num_pages)

    # If for some reason the frontend has some errors
    if page is None:
        page = 1

    # we want our page to always be an integer
    # page = int(page)

    serializer = ConsultTableSerializer(new_consults, many=True)
    return Response({'consults': serializer.data, 'page': page, 'pages': paginator.num_pages})


# Doctor Accept Consult List
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def doctoraccept(request, pk):
    data = request.data

    # get consult
    consult = Consult_table.objects.get(
        consult_id=pk, consult_status="Approved")

    # if consult status is 'Approved' by admin
    if consult.consult_status == 'Approved':
        # set accepted_doctor_id to current user id
        consult.accepted_doctor_id = request.user
    consult.save()

    serializer = ConsultTableSerializer(consult, many=False)
    return Response(serializer.data)


# Doctor Withdraw
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def doctorwithdraw(request, pk):
    data = request.data

    # get consult
    consult = Consult_table.objects.get(
        consult_id=pk, accepted_doctor_id=request.user.id)

    # if consult status is 'Approved' by admin
    if consult.consult_status == 'Approved' or consult.consult_status == 'Active':
        # set accepted_doctor_id to None
        consult.accepted_doctor_id = None
    consult.save()

    serializer = ConsultTableSerializer(consult, many=False)
    return Response(serializer.data)


# Patient Withdraw
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def patientwithdraw(request, pk):
    data = request.data

    # get consult
    consult = Consult_table.objects.get(
        consult_id=pk)

    # if consult status is 'Approved' by admin
    if consult.consult_status == 'Approved' or consult.consult_status == 'Active':
        consult.consult_status = "Inactive"

    consult.save()

    serializer = ConsultTableSerializer(consult, many=False)
    return Response(serializer.data)


# Patient Consult List view
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def patConsultList(request):
    # sortBy and sortOrder
    sortBy = request.query_params.get('sortBy', 'consult_id')
    sortOrder = request.query_params.get('sortOrder', 'asc')
    if sortOrder != 'asc':
        sortBy = '-' + sortBy
    # get consults by patient id
    consults = Consult_table.objects.filter(
        patient_id=request.user.id).order_by(sortBy)
    # For Pagination
    page = request.query_params.get('page')
    # Paginator in this case takes in new_consults we want to paginage, and number means how many should come up on one page
    paginator = Paginator(consults, 5)
    try:
        # if we pass in a page, 'paginator' and 'page' is defined above
        consults = paginator.page(page)
    except PageNotAnInteger:
        # when we have not clicked on a page, means we are on page 1
        consults = paginator.page(1)
    except EmptyPage:
        # If we have am empty page (meaning the page has no products)
        consults = paginator.page(paginator.num_pages)
    # If for some reason the frontend has some errors
    if page == None:
        page = 1
    # we want our page to always be an integer
    # page = int(page)
    serializer = ConsultTableSerializer(consults, many=True)
    return Response({'consults': serializer.data, 'page': page, 'pages': paginator.num_pages})
