from datetime import datetime
from email import message

from django.conf import settings
from django.db import IntegrityError
from consultapp.tokens import account_activation_token, reset_password_token
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from consultapp.serializers import ConsultTableSerializer, CustomUserSerializer, UserSerializerWithToken, Message_serializer
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth.hashers import make_password
from rest_framework import status
from consultapp.models import CustomUser, Consult_table, Language_table, Age_group_table, Message_table
from allauth.socialaccount.providers.google.views import GoogleOAuth2Adapter
from rest_auth.registration.views import SocialLoginView
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from rest_framework.decorators import api_view, permission_classes


# Register User view
@api_view(['POST'])
def register(request):
    data = request.data
    try:
        print('..data', request.data)

        dob = data.get('dob', None)
        if data.get('user_type') == 'Doctor':
            dob = None

        user = CustomUser.objects.create(


            first_name=data['first_name'],
            last_name=data['last_name'],
            gender=data['gender'],
            username=data['email'],
            email=data['email'],
            dob=dob,
            user_type=data.get('user_type'),
            phone_number=data['phone_number'],
            country=data['country'],
            state=data['state'],
            city=data['city'],
            expertise=data.get('expertise', None),
            qualification=data.get('qualification', None),

            password=make_password(data['password'])
        )

        if 'age' in data and 'languages' in data:
            user.age.set(data['age'])
            user.languages.set(data['languages'])

        data = {'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user)}
        subject = 'Register'
        message = f'Hi <b>{user.email}</b>, <i>Thank you</i> for registering your account.<br /> <a href="http://192.168.1.190:8000/verified?uid=' + data.get(
            'uid') + '&token=' + data.get('token') + '">http://192.168.1.190:8000/verified?uid=' + data.get(
            'uid') + "&token=" + data.get('token') + '</a>'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [user.email, ]
        send_mail(subject, message='', from_email=email_from,
                  recipient_list=recipient_list, html_message=message)

        serializer = UserSerializerWithToken(user, many=False)
        print(serializer.data)
        return Response({'detail': 'You have been registered successfully. An account activation mail has been sent to your email'}, status=status.HTTP_200_OK)
    except IntegrityError as e:
        print(e)
        return Response({'detail': 'The email you entered is already registered'}, status=status.HTTP_400_BAD_REQUEST)
    except KeyError as e:
        message = {'detail': str(*e.args) + ' is required'}
        print(e)
        return Response(message, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        print(e)
        return Response({'detail': 'Something went wrong'}, status=status.HTTP_400_BAD_REQUEST)

# token pair view taken from documentation


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)

        serializer = UserSerializerWithToken(self.user).data
        for k, v in serializer.items():
            data[k] = v

        return data


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


# Login view
@ api_view(['POST'])
def login(request):
    data = request.data
    username = data['username']
    password = data['password']

    if username is None:
        return Response({'message': 'Please enter a valid email'})

    if password is None:
        return Response({'message': 'Please enter a valid password'})

    print('..data', username, password)
    info = MyTokenObtainPairSerializer().validate(data)
    if info['user_status'] == 'Activation Pending':
        return Response({'message': 'Please activate your account before logging in', "status": "Activation Pending"},
                        status=status.HTTP_400_BAD_REQUEST)

    if info['user_status'] == 'Deactive':
        return Response({'message': 'Your account has been deactivated by admin. Please contact the admin to activate your account', "status": "Deactivate"},
                        status=status.HTTP_400_BAD_REQUEST)

    return Response(info)


# Resend View
@ api_view(['POST'])
def resendemail(request):
    data = request.data
    email = data['email']
    user = CustomUser.objects.get(email=email)
    data = {'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            'token': account_activation_token.make_token(user)}
    subject = 'Register'
    message = f'Hi <b>{user.email}</b>, <i>Thank you</i> for registering. <br /><a href="http://192.168.1.190:8000/verified?uid=' + data.get(
        'uid') + '&token=' + data.get('token') + '">http://192.168.1.190:8000/verified?uid=' + data.get(
        'uid') + "&token=" + data.get('token') + '</a>'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [user.email, ]
    send_mail(subject, message='', from_email=email_from,
              recipient_list=recipient_list, html_message=message)

    return Response({"message": "An email has been sent to your registered email address"})


# Resetpassword view
@ api_view(['POST'])
def resetpassword(request):
    data = request.data
    email = data['email']
    user = CustomUser.objects.get(email=email)
    print('..user', user.id)
    if user is not None:
        data = {'uid': urlsafe_base64_encode(force_bytes(user.id)),
                'token': reset_password_token.make_token(user)}
        subject = 'Reset Password'
        message = f'Hi <b>{user.email}</b>, Click on the <i>link</i> to reset your password. <a href="http://192.168.1.190:8000/password/reset/confirm?uid=' + data.get(
            'uid') + '&token=' + data.get('token') + '">http://192.168.1.190:8000/password/reset/confirm?uid=' + data.get(
            'uid') + "&token=" + data.get('token') + '</a>'
        # message = f'Hi <b>{user.email}</b>, <i>your reset password</i> request. <a href="http://localhost:3000/password/reset/confirm?uid=' + data.get(
        #     'uid') + '&token=' + data.get('token') + '">http://localhost:3000/password/reset/confirm?uid=' + data.get(
        #     'uid') + "&token=" + data.get('token') + '</a>'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [user.email, ]
        send_mail(subject, message='', from_email=email_from,
                  recipient_list=recipient_list, html_message=message)
        return Response({'message': 'A password reset mail has been sent to your registered email address!'})
    else:
        return Response({'message': 'This email is not registered with us!'}, status=status.HTTP_400_BAD_REQUEST)


# Reset_confirm Password view
@ api_view(['POST'])
def verify_reset_password(request):
    data = request.data
    uid = data['uid']
    token = data['token']
    new_password = data['new_password']
    try:
        uid = force_text(urlsafe_base64_decode(uid))
        user = CustomUser.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None
    if user is None:
        return Response('Invalid token!')
    if not reset_password_token.check_token(user, token):
        return Response('Activation link has expired!', status=status.HTTP_400_BAD_REQUEST)
    else:
        user.set_password(new_password)
        user.save()
        return Response('Your password has been updated successfully. Now you can login to your account.')


# Email Link activation view

@ api_view(['POST'])
def activate(request):
    data = request.data
    uid = data['uid']
    token = data['token']
    try:
        uid = force_text(urlsafe_base64_decode(uid))
        user = CustomUser.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.user_status = 'Activate'
        user.save()
        return Response('Thank you for your email confirmation. Now you can login your account.')
    else:
        return Response('Activation link is invalid!')


# Update profile By User
@ api_view(['PUT'])
@ permission_classes([IsAuthenticated])
def profile(request):
    user = request.user
    serializer = CustomUserSerializer(user, many=False)

    data = request.data

    dob = data.get('dob', None)
    if data.get('user_type') == 'Doctor':
        dob = None

    if data.get('password'):
        user.set_password(data['password'])

    else:
        user.first_name = data['first_name']
        user.last_name = data['last_name']
        user.email = data['email']
        user.phone_number = data['phone_number']
        user.country = data['country']
        user.state = data['state']
        user.city = data['city']
        user.dob = dob

        user.expertise = data['expertise']
        user.qualification = data['qualification']
        user.modified_at = datetime.now()

        user.age.set(data['age'])
        user.languages.set(data['languages'])

    user.save()
    serializer = UserSerializerWithToken(user, many=False)
    return Response(serializer.data)


# Get UserDetails By Id
@ api_view(['GET'])
@ permission_classes([IsAuthenticated])
def getUserById(request, pk):
    user = CustomUser.objects.get(id=pk)
    serializer = CustomUserSerializer(user, many=False)
    return Response(serializer.data)


# Get userProfile
@ api_view(['GET'])
@ permission_classes([IsAuthenticated])
def getUserProfile(request):
    user = request.user
    serializer = CustomUserSerializer(user, many=False)
    return Response(serializer.data)
