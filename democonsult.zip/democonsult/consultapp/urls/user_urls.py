from django.urls import path
from consultapp.views import user_views as views


from rest_framework_simplejwt.views import (
    TokenRefreshView,
)


# User Urls
urlpatterns = [
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('register', views.register, name='register'),
    path('login/', views.login, name='token_obtain_pair'),
    path('user/<str:pk>/', views.getUserById, name='user'),
    path('profile', views.getUserProfile, name="users-profile"),
    path('profile/update', views.profile, name="user-profile-update"),
    path('activate', views.activate, name='activate'),
    path('resendmail', views.resendemail, name='resendmail'),
    path('resetpassword', views.resetpassword, name='resetpassword'),
    path('verifyresetpassword', views.verify_reset_password, name='verifyresetpassword'),
    ]