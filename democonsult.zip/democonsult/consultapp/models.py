from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser

# Role Choices

usertype = [
    ("Patient", "Patient"),
    ("Doctor", "Doctor"),
]

# gender choices
gender_choices = [
    ("Male", "Male"),
    ("Female", "Female"),
]

# status Choices
status_choices = [
    ('Activate', 'Activate'),
    ('Activation Pending', 'Activation Pending'),
    ('Deactive', 'Deactive'),
]

# Approved Choices

approved_status = [
    ('Pending', 'Pending'),
    ('Approved', 'Approved'),
    ('Unapproved', 'Unapproved'),
    ('Active', 'Active'),
    ('Inactive', 'Inactive')
]


# Create your models here.


# Admin Model
class Admin_table(models.Model):
    admin_id = models.AutoField(primary_key=True)
    admin_name = models.CharField(max_length=50)
    admin_email = models.EmailField(null=True, blank=True, unique=True)
    admin_password = models.CharField(max_length=50)

    def __str__(self):
        return self.admin_name


# user Model
class CustomUser(AbstractUser):
    languages = models.ManyToManyField("Language_table")
    age = models.ManyToManyField("Age_group_table", blank=True)
    first_name = models.CharField(max_length=30, null=True, blank=True)
    last_name = models.CharField(max_length=30, null=True, blank=True)
    gender = models.CharField(
        choices=gender_choices, max_length=60, null=True, blank=True, default="Male")
    email = models.EmailField(null=True, blank=True)
    phone_number = models.CharField(max_length=30, null=True, blank=True)
    country = models.CharField(max_length=50, null=True, blank=True)
    state = models.CharField(max_length=50, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    expertise = models.TextField(max_length=1200, null=True, blank=True)
    qualification = models.TextField(max_length=1200, null=True, blank=True)
    user_type = models.CharField(
        choices=usertype, max_length=20, null=True, blank=True)
    user_status = models.CharField(
        choices=status_choices, max_length=60, null=True, blank=True, default="Activation Pending")
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.first_name


# Consult_model
class Consult_table(models.Model):
    consult_id = models.AutoField(primary_key=True, editable=False)
    patient_id = models.ForeignKey(
        CustomUser, related_name="patientconsult", on_delete=models.CASCADE, blank=True, null=True)
    accepted_doctor_id = models.ForeignKey(
        CustomUser, related_name="doctorconsult", on_delete=models.CASCADE, null=True, blank=True)

    first_name = models.CharField(max_length=30, null=True, blank=True)
    last_name = models.CharField(max_length=30, null=True, blank=True)
    email = models.EmailField(null=True, blank=True, unique=False)
    phone_number = models.IntegerField(null=True, blank=True)
    country = models.CharField(max_length=50, null=True, blank=True)
    state = models.CharField(
        max_length=50, default='false', null=True, blank=True)
    city = models.CharField(max_length=50, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    createdAt = models.DateTimeField(
        auto_now_add=True)
    approved_by = models.ForeignKey(
        "Admin_table", on_delete=models.CASCADE, null=True, blank=True)
    # user_status = models.CharField(max_length=60,
    #                                choices=status_choices, null=True, blank=True)
    approved_at = models.DateTimeField(
        auto_now_add=False, null=True, blank=True)
    withdraw_date = models.DateTimeField(
        auto_now_add=False, null=True, blank=True)
    withdraw_reason = models.TextField(max_length=300, null=True, blank=True)
    preferred_time = models.DateTimeField(null=True, blank=True)
    consult_status = models.CharField(
        choices=approved_status, max_length=50, default='Pending')


# Message model
class Message_table(models.Model):
    message_id = models.AutoField(primary_key=True, editable=False)
    consult_id = models.ForeignKey(
        Consult_table, on_delete=models.CASCADE, null=True, blank=True)
    sender_id = models.ForeignKey(
        CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    recipient_id = models.ForeignKey(
        CustomUser, related_name="recipient_id", on_delete=models.CASCADE, null=True, blank=True)

    message_type = models.CharField(max_length=60, null=True, blank=True)
    message = models.TextField(null=True, blank=True)
    file_name = models.ImageField(
        upload_to="consult_file", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.message_id)


# Age model
class Age_group_table(models.Model):
    age_id = models.AutoField(primary_key=True, editable=False)
    age_min = models.IntegerField(null=True, blank=True)
    age_max = models.IntegerField(null=True, blank=True)
    status = models.CharField(choices=status_choices, max_length=60,
                              null=True, blank=True, default='Inactive')

    def __str__(self):
        return str(self.age_id)


# Language model
class Language_table(models.Model):
    language_id = models.AutoField(primary_key=True, editable=False)
    language_name = models.CharField(
        max_length=20)
    status = models.CharField(
        max_length=20, choices=status_choices, blank=True, null=True, default='Inactive')

    def __str__(self):
        return self.language_name


# Country model
class Country_table(models.Model):
    country_id = models.AutoField(primary_key=True, editable=False)
    country_name = models.CharField(max_length=60, blank=True, null=True)

    def __str__(self):
        return self.country_name


# state model
class State_table(models.Model):
    state_id = models.AutoField(primary_key=True, editable=False)
    country_id = models.ForeignKey(
        Country_table, on_delete=models.CASCADE, null=True, blank=True)
    state_name = models.CharField(max_length=60, null=True, blank=True)

    def __str__(self):
        return self.state_name
