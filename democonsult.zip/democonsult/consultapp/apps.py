from django.apps import AppConfig


class ConsultappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consultapp'

    # used for signals.py
    def ready(self):
        import consultapp.signals
