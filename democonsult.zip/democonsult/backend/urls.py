from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import render
from django.views.generic import TemplateView
# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
#
#     # register url
#     path('register', views.register, name='register'),
#     path('language', views.languageview, name='language'),
#     path('agegroup', views.agegroupview, name='age'),
#     path("doctoraccept/<str:pk>/", views.doctoraccept, name='doctor-accept'),
#     path("doctorwithdraw/<str:pk>/", views.doctorwithdraw, name='doctor-withdraw'),
#
#     # Login Url
#     path('login/', views.login, name='token_obtain_pair'),
#     #  Consult list for doctors
#     # path('docConsultList/', views.getDocConsults, name='doc-consults-list'),
#     path('doctor/consultlist/', views.docConsultList, name='doc-consult-list'),
#     path('patient/consultlist/', views.patConsultList, name='pat-consult-list'),
#     path('chat/', views.messageDetails, name='chat'),
#     # path('postchat', views.postmessage, name='postmessage'),
#
#     # update profile
#     path('user/<str:pk>/', views.getUserById, name='user'),
#     path('consult/form', views.consult, name='consult-form'),
#     path('message', views.messageDetails, name='consult-messages'),
#     path('profile', views.getUserProfile, name="users-profile"),
#     path('profile/update', views.profile, name="user-profile-update"),
#     path('rest-auth/google/', GoogleLogin.as_view(), name='google_login'),
#
#     path('activate', views.activate, name='activate'),
#     path('resendmail', views.resendemail, name='resendmail'),
#     path('resetpassword', views.resetpassword, name='resetpassword'),
#     path('verifyresetpassword', views.verify_reset_password, name='verifyresetpassword'),
# ]

def index(request):
    return render(request, "build/index.html")

urlpatterns = [

    path('admin/', admin.site.urls),
    path('', include('consultapp.urls.age_urls')),
    path('', include('consultapp.urls.chat_urls')),
    path('', include('consultapp.urls.consult_urls')),
    path('', include('consultapp.urls.language_urls')),
    path('', include('consultapp.urls.user_urls')),
    re_path(r'^(?:.*)/?$', TemplateView.as_view(template_name='index.html')),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
